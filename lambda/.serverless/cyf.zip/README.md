Current home for functions required for the website
This is to be split out as a separate repo at a later stage
Functions will be adjusted to run on Firebase or Lambda at a later stage, to run locally:

```
yarn install
yarn start
```