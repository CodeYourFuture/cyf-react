'use strict';
const stripe = require('./functions/stripe');

module.exports.stripe = stripe;
